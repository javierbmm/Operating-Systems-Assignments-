//
// Created by Olívia Rey Pellicer on 25/10/2019.
//

#ifndef PROJECTF1_1_PARSINGINPUTS_H
#define PROJECTF1_1_PARSINGINPUTS_H
int parseInput(char *user);

#endif //PROJECTF1_1_PARSINGINPUTS_H
