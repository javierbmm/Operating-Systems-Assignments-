//
// Created by Olívia Rey Pellicer on 25/10/2019.
//

#ifndef PROJECTF1_1_COMMANDSACTIONS_H
#define PROJECTF1_1_COMMANDSACTIONS_H
void getCommand(int i, char* user);

#endif //PROJECTF1_1_COMMANDSACTIONS_H
